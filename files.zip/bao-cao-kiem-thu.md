# Báo cáo kết quả kiểm thử – YouTube Xu (Sprint 5)

> Chỉ điền kết quả thật sau khi đã chạy. Chưa chạy thì để trống, không ghi Pass (đúng quy tắc trong Issue #8). Cột "Chạy trên" cho biết test chạy trên SQLite trong bộ nhớ hay SQL Server thật.

## 1. Thông tin chung

| Mục | Nội dung |
|---|---|
| Người thực hiện | TV5 |
| Ngày kiểm thử | `<dd/mm/yyyy>` |
| Branch / commit | `<tên nhánh, mã commit>` |
| Môi trường | Windows, Node.js `<phiên bản>`, SQL Server `<phiên bản / SQLEXPRESS>`, ODBC Driver 18 |
| Lệnh chạy test logic | `node --import ./tests/setup/register.mjs --test ./tests/<tên file>.test.mjs` |
| Lệnh chạy lint | `<npm.cmd run lint>` |
| Link workflow GitHub Actions | `<link lần chạy>` |

**Lưu ý phạm vi:** các test hiện có gọi route handler thật nhưng dùng SQLite trong bộ nhớ. Đây là kiểm tra logic, không thay thế kiểm thử trên SQL Server thật (theo README). Mục 3.2 và 3.4 cần chạy thêm trên SQL Server thật.

## 2. Phạm vi kiểm thử

- Transaction ví và đổi quà
- Tính toàn vẹn dữ liệu (ràng buộc, đối soát)
- Hiệu năng truy vấn
- Phân quyền và tích hợp frontend, API, SQL Server
- Lint và test tự động bằng GitHub Actions

## 3. Kết quả chi tiết

### 3.1 Transaction

| Mã | Tình huống | Kết quả mong đợi | Chạy trên | Kết quả thực tế | Đạt/Không |
|---|---|---|---|---|---|
| TX-01 | Đổi quà thành công | Trừ `xu_balance`, trừ `stock_qty`, tạo đơn trong `redemptions` và dòng `REDEEM` trong `xu_transactions` cùng một transaction | | | |
| TX-02 | Số dư không đủ | Từ chối; số dư và tồn kho không đổi | | | |
| TX-03 | Quà hết hàng (`stock_qty = 0`) | Từ chối; không trừ xu | | | |
| TX-04 | Gửi lại cùng `request_key` | Không trừ xu hoặc tồn kho lần hai; không tạo đơn mới | | | |
| TX-05 | Hai request đồng thời khi chỉ đủ xu hoặc tồn kho cho một lần | Chỉ một request thành công | | | |
| TX-06 | Lỗi giữa chừng khi ghi sổ cái (giả lập) | Rollback toàn bộ, không còn đơn hoặc số dư lệch | | | |
| TX-07 | Tạo chiến dịch kèm đối tượng mục tiêu, lỗi ở bước `ad_targeting` | Không còn chiến dịch mồ côi | | | |
| TX-08 | Admin từ chối đơn đổi quà | Hoàn xu và tồn kho, có dòng `REFUND` trong sổ cái | | | |

### 3.2 Toàn vẹn dữ liệu

| Mã | Tình huống | Kết quả mong đợi | Chạy trên | Kết quả thực tế | Đạt/Không |
|---|---|---|---|---|---|
| DI-01 | Thêm hai lượt xem cùng `user_id`, `ad_id`, `view_date` | Bị `uq_user_ad_day` chặn | SQL Server | | |
| DI-02 | Thêm `view_token` trùng | Bị chặn | SQL Server | | |
| DI-03 | Đặt `xu_balance` âm | Bị `chk_balance` chặn | SQL Server | | |
| DI-04 | `spent_xu > budget_xu`, `end_date < start_date`, `duration_sec` ngoài 5–60 | Bị CHECK chặn | SQL Server | | |
| DI-05 | Thêm chiến dịch với `advertiser_id` hoặc `category_id` không tồn tại | Bị khóa ngoại chặn | SQL Server | | |
| DI-06 | Gán `status` hoặc `txn_type` ngoài danh sách | Bị CHECK chặn | SQL Server | | |
| DI-07 | Đối soát số dư với sổ cái (query 5.2 trong file rà soát) | 0 dòng lệch | SQL Server | | |
| DI-08 | Đối soát `spent_xu` với `ad_views` (query 5.3) | 0 dòng lệch | SQL Server | | |
| DI-09 | Nhận thưởng nhiệm vụ hai lần trong một ngày (nếu đã có bảng nhiệm vụ) | Bị `UNIQUE` hoặc logic chặn | SQL Server | | |

### 3.3 Hiệu năng truy vấn

Dữ liệu mẫu rất nhỏ nên cần nạp thêm dữ liệu vào một bản sao database riêng trước khi đo. Ghi số dòng thật của mỗi bảng.

| Truy vấn | Số dòng dữ liệu | Logical reads trước | Thời gian trước (ms) | Logical reads sau | Thời gian sau (ms) | Index đã thêm |
|---|---|---|---|---|---|---|
| Danh sách quảng cáo đang chạy theo danh mục | | | | | | |
| Lịch sử ví (25 giao dịch đầu, lọc theo loại) | | | | | | |
| Thống kê chiến dịch của một nhà quảng cáo | | | | | | |
| Danh sách đơn đổi quà chờ duyệt (Admin) | | | | | | |
| Bảng xếp hạng Top 20 | | | | | | |

### 3.4 Phân quyền và tích hợp (frontend, API, SQL Server)

| Mã | Luồng kiểm thử | Kết quả mong đợi | Chạy trên | Kết quả thực tế | Đạt/Không |
|---|---|---|---|---|---|
| IT-01 | Đăng nhập, đăng xuất | Cookie phiên được tạo rồi xóa | SQL Server | | |
| IT-02 | Gửi `userId` hoặc `role` giả trong request | Bị bỏ qua, quyền lấy từ database | SQL Server | | |
| IT-03 | Nhà quảng cáo tạm dừng, tiếp tục, kết thúc chiến dịch của mình | Thành công, trạng thái đúng | SQL Server | | |
| IT-04 | Nhà quảng cáo thao tác chiến dịch của người khác | Bị từ chối, dữ liệu không đổi | SQL Server | | |
| IT-05 | Người xem gọi API của nhà quảng cáo hoặc Admin | Bị từ chối | SQL Server | | |
| IT-06 | Ví xu phân trang 25 giao dịch, lọc loại, tải thêm | Đúng dữ liệu, tổng số liệu tính trên toàn bộ giao dịch | SQL Server | | |
| IT-07 | Admin duyệt đơn đổi quà không nhập mã quà | Bị từ chối | SQL Server | | |
| IT-08 | Nhận Xu từ quảng cáo (giao diện và API) | Bị khóa ở cả hai | SQL Server | | |
| IT-09 | Dữ liệu đầu vào sai (thiếu trường, sai kiểu) | Trả mã lỗi hợp lý, không ghi vào database | SQL Server | | |

### 3.5 Lint, test và CI (GitHub Actions)

| Mục | Kết quả |
|---|---|
| Workflow chạy khi tạo Pull Request hoặc push nhánh quy định | |
| Lint đạt | |
| Test đạt / tổng số test | |
| Thời gian chạy | |
| Không lộ secret trong log | |

## 4. Lỗi phát hiện

| # | Mô tả lỗi | Mức độ | Cách tái hiện | Cách xử lý | Trạng thái |
|---|---|---|---|---|---|
| 1 | | | | | |

## 5. Tổng kết

- Tổng số test case: `<n>`, đạt: `<n>`, không đạt: `<n>`, chưa chạy: `<n>`.
- Nhận xét về độ ổn định của giao dịch ví, đổi quà và phân quyền.
- Giới hạn còn lại (ví dụ phần chạy trên SQLite chưa kiểm chứng trên SQL Server thật): `<...>`.
- Việc tồn đọng và đề xuất: `<...>`.
