# Hướng dẫn chạy migration – YouTube Xu

Tài liệu này bổ sung cho README. Thay các chỗ `<...>` bằng thông tin thật, riêng dòng migration Sprint 5 cần bạn điền tên file.

## 1. Yêu cầu môi trường

- Windows, Node.js 18.17 trở lên (chạy test cần Node.js 22.5 trở lên)
- SQL Server (mặc định instance `localhost\SQLEXPRESS`), Microsoft ODBC Driver 18 for SQL Server, công cụ `sqlcmd`
- Tài khoản Windows hiện tại được phép đăng nhập SQL Server bằng Windows Authentication
- Quyền tạo bảng, index và ràng buộc trên database `youtube_xu`

## 2. Cấu hình

Đặt trong `.env.local` (không commit, không chia sẻ):

| Biến | Ý nghĩa | Mặc định |
|---|---|---|
| `AUTH_SECRET` | Khóa ký phiên đăng nhập, ngẫu nhiên, tối thiểu 32 ký tự | Tự sinh bằng khối lệnh trong README |
| `DB_HOST` | Máy chủ SQL Server | `localhost\SQLEXPRESS` |
| `DB_NAME` | Tên database | `youtube_xu` |

Nếu dùng SQL Server khác, đổi giá trị sau `-S` trong các lệnh bên dưới.

## 3. Chọn trường hợp

| Tình huống | Làm theo |
|---|---|
| Máy mới, hoặc database demo không cần giữ dữ liệu | Mục 4 |
| Đã có database và cần giữ dữ liệu | Mục 5 |

## 4. Cài mới (xóa và tạo lại database)

**Cảnh báo:** script xóa database `youtube_xu` nếu đã tồn tại. Không chạy khi cần giữ dữ liệu.

```
sqlcmd -S ".\SQLEXPRESS" -E -I -b -f i:65001 -i ".\youtube_xu_database.sql"
```

Script đã gộp sẵn các migration cũ, nên không chạy lại các file trong `migrations/` sau lệnh này. Nếu migration Sprint 5 chưa được gộp vào script, chạy tiếp theo mục 5 từ bước 3.

Ý nghĩa tham số: `-E` dùng Windows Authentication, `-I` bật `QUOTED_IDENTIFIER` (cần cho filtered index), `-b` dừng khi gặp lỗi, `-f i:65001` đọc file UTF-8 để không lỗi tiếng Việt.

## 5. Database đã có dữ liệu

**Bước 1. Dừng ứng dụng** (Ctrl+C ở cửa sổ đang chạy `npm.cmd run dev`).

**Bước 2. Sao lưu:**

```
sqlcmd -S ".\SQLEXPRESS" -E -b -Q "BACKUP DATABASE youtube_xu TO DISK = 'C:\Backup\youtube_xu_truoc_migration.bak' WITH INIT"
```

Thư mục `C:\Backup` phải tồn tại và tài khoản dịch vụ SQL Server phải ghi được vào đó.

**Bước 3. Chạy migration theo thứ tự**, mỗi lệnh thành công mới chạy lệnh tiếp:

```
sqlcmd -S ".\SQLEXPRESS" -E -I -b -f i:65001 -i ".\migrations\20261020_add_referral_codes.sql"
sqlcmd -S ".\SQLEXPRESS" -E -I -b -f i:65001 -i ".\migrations\20261022_add_redemption_idempotency.sql"
sqlcmd -S ".\SQLEXPRESS" -E -I -b -f i:65001 -i ".\migrations\20261022_add_demo_video_campaigns.sql"
sqlcmd -S ".\SQLEXPRESS" -E -I -b -f i:65001 -i ".\migrations\<migration-sprint-5>.sql"
```

| Thứ tự | File | Tác dụng | Chạy lại an toàn? |
|---|---|---|---|
| 1 | `20261020_add_referral_codes.sql` | Thêm mã giới thiệu cho người dùng | Mở file kiểm tra có `IF NOT EXISTS` |
| 2 | `20261022_add_redemption_idempotency.sql` | Thêm cột khóa yêu cầu tùy chọn và unique index có lọc để lặp lại cùng request key không trừ xu hoặc tồn kho lần nữa. Đơn cũ giữ `NULL` | Mở file kiểm tra có `IF NOT EXISTS` |
| 3 | `20261022_add_demo_video_campaigns.sql` | Thêm các chiến dịch video mẫu | Có (theo README) |
| 4 | `<migration-sprint-5>.sql` | `<mô tả>` | `<có/không>` |

Các migration không xóa dữ liệu hiện có. Dự án chưa có bảng lưu lịch sử migration, nên hãy ghi lại thủ công ngày đã chạy ở từng môi trường.

**Bước 4. Kiểm tra** (mục 6), rồi **chạy lại ứng dụng** và thử nhanh: đăng nhập `admin@youtubexu.vn`, mở danh sách quảng cáo, mở tab Ví xu.

## 6. Kiểm tra sau khi chạy

```sql
USE youtube_xu;

-- Migration 1: cột mã giới thiệu (khác NULL là có cột)
SELECT COL_LENGTH('users', 'referral_code') AS referral_code_length;

-- Migration 2: cột request_key và unique index có lọc
SELECT COL_LENGTH('redemptions', 'request_key') AS request_key_length;
SELECT name, is_unique, has_filter
FROM sys.indexes
WHERE object_id = OBJECT_ID('redemptions') AND name = 'uq_redemptions_request_key';

-- Danh sách bảng và index hiện có
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES ORDER BY TABLE_NAME;
SELECT OBJECT_NAME(object_id) AS [table], name
FROM sys.indexes
WHERE name IS NOT NULL AND OBJECTPROPERTY(object_id, 'IsUserTable') = 1
ORDER BY [table], name;
```

Kiểm tra thêm tính nhất quán dữ liệu bằng query đối soát trong `rasoat-cau-truc-sql-server.md` (mục 5).

## 7. Rollback khi lỗi

Các migration hiện chưa có file "down", nên cách an toàn là khôi phục từ bản sao lưu ở bước 2:

```sql
USE master;
ALTER DATABASE youtube_xu SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
RESTORE DATABASE youtube_xu
FROM DISK = 'C:\Backup\youtube_xu_truoc_migration.bak'
WITH REPLACE;
ALTER DATABASE youtube_xu SET MULTI_USER;
```

Dữ liệu phát sinh sau thời điểm sao lưu sẽ mất. Vì vậy hãy dừng ứng dụng trước khi migration và khôi phục ngay khi phát hiện lỗi.

## 8. Lỗi thường gặp

| Lỗi | Nguyên nhân thường gặp | Cách xử lý |
|---|---|---|
| `CREATE INDEX failed because the following SET options have incorrect settings: 'QUOTED_IDENTIFIER'` (Msg 1934) | `sqlcmd` mặc định tắt `QUOTED_IDENTIFIER`, trong khi filtered index cần bật | Thêm `-I` vào lệnh, hoặc thêm `SET QUOTED_IDENTIFIER ON;` đầu file |
| Chữ tiếng Việt bị lỗi hoặc thành `?` | Thiếu `-f i:65001` hoặc file không lưu UTF-8 | Thêm `-f i:65001`, lưu file `.sql` dạng UTF-8 |
| `Login failed for user` | Tài khoản Windows chưa có quyền, hoặc dịch vụ SQL Server chưa chạy | Kiểm tra dịch vụ `SQL Server (SQLEXPRESS)` đang chạy, cấp quyền cho tài khoản |
| `Cannot open database "youtube_xu"` | Chưa chạy script khởi tạo | Làm mục 4 (nếu không cần giữ dữ liệu) |
| `Operating system error 5 (Access is denied)` khi sao lưu | Thư mục sao lưu không cho tài khoản dịch vụ SQL Server ghi | Chọn thư mục khác hoặc cấp quyền ghi |
| `There is already an object named ...` hoặc `Column names in each table must be unique` | Migration đã chạy trước đó | Kiểm tra bằng mục 6, bỏ qua file đã chạy và chạy tiếp file kế tiếp |
| `conflicted with the CHECK constraint` hoặc `... FOREIGN KEY constraint` khi thêm ràng buộc | Dữ liệu cũ vi phạm ràng buộc mới | Tìm dòng vi phạm bằng SELECT, sửa dữ liệu, chạy lại |
| Ứng dụng không kết nối được database | Chưa cài ODBC Driver 18, hoặc sai `DB_HOST`, `DB_NAME` | Cài driver, kiểm tra `.env.local` |

## 9. Checklist trước khi merge Pull Request có migration

- [ ] Không có `DROP DATABASE`, `DROP TABLE` hoặc lệnh xóa dữ liệu
- [ ] Chạy lại migration lần hai không lỗi (có `IF NOT EXISTS`)
- [ ] Đã chạy thử trên bản sao database đã sao lưu
- [ ] Đã cập nhật `youtube_xu_database.sql` cho khớp với migration
- [ ] Đã cập nhật README và tài liệu này
- [ ] Không có mật khẩu, token hoặc `AUTH_SECRET` trong file hay log
