# Rà soát cấu trúc SQL Server – YouTube Xu (Sprint 5, TV5)

**Đã đọc:** `youtube_xu_database.sql` trên nhánh `main` (8 bảng) và Issue #8.
**Chưa đọc được:** các file trong `migrations/`, thư mục `tests/` và các nhánh khác. Chỗ nào ghi "đối chiếu" là bạn cần so với migration hoặc nhánh của bạn.

## 1. Schema hiện có

`ad_categories`, `users`, `ads`, `ad_targeting`, `ad_views`, `rewards`, `redemptions`, `xu_transactions`.

Script khởi tạo đã gộp sẵn nội dung 3 migration cũ (mã giới thiệu, `request_key`, video mẫu), nên script và thư mục `migrations/` phải luôn khớp nhau.

Điểm tốt nên giữ:

- `CHECK (xu_balance >= 0)` và `CHECK (stock_qty >= 0)` là lưới an toàn khi hai request đổi quà chạy cùng lúc.
- `UNIQUE (user_id, ad_id, view_date)` và `view_token UNIQUE` chặn xem lặp.
- Unique index có lọc trên `redemptions(request_key)` phục vụ chống xử lý trùng.
- Sổ cái `xu_transactions` có `balance_after`, thuận tiện đối soát.

## 2. Năm chức năng mới cần gì từ database

| Chức năng | Bảng hiện có đáp ứng chưa? | Cần có (đối chiếu migration của bạn) |
|---|---|---|
| Thông báo | Chưa | `notifications`: `user_id` (FK), tiêu đề, nội dung, loại, `is_read`, `created_at`. Index `(user_id, is_read, created_at)` |
| Bảng xếp hạng | Tính được từ `xu_transactions` + `users`, không bắt buộc bảng mới | Index `(txn_type, created_at) INCLUDE (user_id, amount)`; chốt định nghĩa "xu kiếm được" |
| Nhiệm vụ hằng ngày | Chưa | `daily_tasks` (mã, loại, mục tiêu, thưởng > 0, đang bật) và `user_daily_tasks` (`user_id`, `task_id`, `task_date`, tiến độ, trạng thái, `claimed_at`) với `UNIQUE (user_id, task_id, task_date)` để chặn nhận thưởng hai lần |
| Hỗ trợ | Chưa | `support_tickets` (`user_id`, nhóm, tiêu đề, nội dung, mã giao dịch hoặc đơn đổi quà tùy chọn có FK, trạng thái 4 giá trị, `created_at`, `updated_at`) và `support_replies` (`ticket_id` FK, người trả lời, nội dung, `created_at`) |
| Báo cáo | Tính được từ `ads`, `ad_views`, `xu_transactions`, `redemptions` | Các index ở mục 4; định nghĩa rõ từng chỉ số |

Issue đề xuất tên kiểu `Notifications`, `NotificationID`, nhưng schema hiện tại dùng snake_case chữ thường (`xu_transactions`, `user_id`). Nên giữ snake_case cho nhất quán.

Nhiệm vụ "xem quảng cáo" phải giữ trạng thái khóa nhận thưởng vì chưa có cơ chế xác minh lượt xem thật (đúng với điều kiện bắt buộc trong issue).

## 3. Vấn đề phát hiện

| # | Mức | Vấn đề | Đề xuất | Trạng thái |
|---|---|---|---|---|
| 1 | Cao | Cột khóa ngoại và cột lọc chưa có index: `ads.advertiser_id`, `ads.category_id`, `ad_targeting.ad_id`, `ad_views.ad_id`, `xu_transactions.view_id`, `xu_transactions.redemption_id`, `redemptions.reward_id`, `users.referred_by`. Dashboard nhà quảng cáo, lọc theo danh mục và thống kê theo chiến dịch sẽ quét cả bảng khi dữ liệu lớn | Thêm index ở mục 4, đo trước/sau rồi mới giữ | |
| 2 | Cao | Dữ liệu mẫu không đối soát được. `ads.spent_xu` lệch tổng từ `ad_views` (chiến dịch 1 ghi 3500 xu nhưng `ad_views` chỉ có 1 lượt hoàn tất, 10 xu; chiến dịch 2, 3, 5 cũng lệch). Năm tài khoản có số dư nhưng không có dòng nào trong sổ cái (user 2, 3, 4, 7, 8). Đơn đổi quà #2 và #3 không có dòng `REDEEM`. Issue yêu cầu thống kê khớp dữ liệu nguồn | Chọn nguồn sự thật cho dashboard (nên là `ad_views` và `xu_transactions`) hoặc sửa dữ liệu mẫu cho khớp. Chạy 2 query đối soát ở mục 5 | |
| 3 | Trung bình | Ràng buộc chỉ nằm trong code: tuổi nhắm mục tiêu (README nói 16–120, DB không kiểm tra, cả `age_from <= age_to`), `ads.reward_xu > 0` và `<= budget_xu`, `ads.spent_xu >= 0`, `rewards.face_value_vnd > 0`, `redemptions.xu_spent > 0`, `ad_views.watched_seconds >= 0` | Thêm CHECK bằng migration. Tìm dòng cũ vi phạm bằng SELECT trước, vì thêm CHECK sẽ lỗi nếu dữ liệu cũ sai | |
| 4 | Trung bình | Nếu nhiệm vụ cộng xu qua `xu_transactions`: cột `txn_type` đang bị CHECK trong 5 giá trị (`EARN`, `REDEEM`, `REFUND`, `BONUS`, `ADJUST`) và CHECK này không có tên, nên migration phải tra tên trong `sys.check_constraints` rồi mới DROP/ADD được | Chốt với TV3: dùng `BONUS` cho thưởng nhiệm vụ (khỏi sửa CHECK) hoặc thêm loại mới bằng migration | |
| 5 | Trung bình | Script dùng filtered unique index trên `redemptions(request_key)` và có INSERT vào bảng này. Cả hai cần `QUOTED_IDENTIFIER ON`, trong khi `sqlcmd` mặc định tắt và các lệnh trong README không có `-I`. Mình chưa chạy thử vì không có SQL Server ở đây | Chạy đúng lệnh trong README trên máy sạch. Nếu gặp lỗi 1934 thì thêm `-I` (hoặc `SET QUOTED_IDENTIFIER ON;` đầu file) và cập nhật README | |
| 6 | Trung bình | `users.created_at` và `ads.created_at` có `DEFAULT` nhưng cho phép NULL, các bảng khác đều NOT NULL | Thống nhất NOT NULL (cập nhật dòng NULL trước nếu có) | |
| 7 | Thấp | `ad_targeting` lặp tuổi và giới tính cho từng tỉnh (chiến dịch 2 có 2 dòng cùng 16–45) và không có UNIQUE nên có thể trùng dòng. Về lý thuyết đây là phụ thuộc bắc cầu qua `ad_id`, lệch với dòng "chuẩn 3NF" ở đầu script | Giữ nếu chủ ý (chuẩn bị lời giải thích nếu giảng viên hỏi) hoặc thêm UNIQUE | |
| 8 | Thấp | Sổ cái "bất biến" chỉ là quy ước, chưa có gì chặn UPDATE hoặc DELETE trên `xu_transactions` | Tùy chọn: trigger chặn, hoặc phân quyền cho tài khoản ứng dụng | |
| 9 | Thấp | `DATETIME` + `CURRENT_TIMESTAMP` lưu giờ máy chủ; lọc tuần/tháng cho bảng xếp hạng và báo cáo cần thống nhất múi giờ | Ghi rõ trong tài liệu, hoặc chuyển sang `DATETIME2` | |

## 4. Index đề xuất

Mỗi index chỉ tạo nếu chưa có, không đụng đến dữ liệu. Chỉ giữ index nào đo thấy có lợi (issue yêu cầu ghi số liệu trước/sau, không tự đặt số).

```sql
USE youtube_xu;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_ads_advertiser' AND object_id = OBJECT_ID('ads'))
    CREATE INDEX idx_ads_advertiser ON ads(advertiser_id, status);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_ads_category' AND object_id = OBJECT_ID('ads'))
    CREATE INDEX idx_ads_category ON ads(category_id, status);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_targeting_ad' AND object_id = OBJECT_ID('ad_targeting'))
    CREATE INDEX idx_targeting_ad ON ad_targeting(ad_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_views_ad' AND object_id = OBJECT_ID('ad_views'))
    CREATE INDEX idx_views_ad ON ad_views(ad_id, view_status, view_date);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_txn_type_time' AND object_id = OBJECT_ID('xu_transactions'))
    CREATE INDEX idx_txn_type_time ON xu_transactions(txn_type, created_at) INCLUDE (user_id, amount);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_txn_view' AND object_id = OBJECT_ID('xu_transactions'))
    CREATE INDEX idx_txn_view ON xu_transactions(view_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_txn_redemption' AND object_id = OBJECT_ID('xu_transactions'))
    CREATE INDEX idx_txn_redemption ON xu_transactions(redemption_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_redemptions_status' AND object_id = OBJECT_ID('redemptions'))
    CREATE INDEX idx_redemptions_status ON redemptions(status, requested_at);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_redemptions_reward' AND object_id = OBJECT_ID('redemptions'))
    CREATE INDEX idx_redemptions_reward ON redemptions(reward_id);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'idx_users_referred_by' AND object_id = OBJECT_ID('users'))
    CREATE INDEX idx_users_referred_by ON users(referred_by);
GO
```

Dữ liệu mẫu rất nhỏ (24 chiến dịch, 6 lượt xem) nên SQL Server sẽ quét bảng dù có index. Muốn đo hiệu năng thật, hãy nạp thêm dữ liệu vào một bản sao database riêng, không dùng database demo.

## 5. Query hữu ích

### 5.1 Khóa ngoại chưa có index (kiểm tra lại sau khi thêm index)

```sql
SELECT OBJECT_NAME(fk.parent_object_id) AS [table],
       fk.name AS fk_name,
       COL_NAME(fkc.parent_object_id, fkc.parent_column_id) AS fk_column
FROM sys.foreign_keys fk
JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
WHERE fkc.constraint_column_id = 1
  AND NOT EXISTS (
      SELECT 1 FROM sys.index_columns ic
      WHERE ic.object_id = fkc.parent_object_id
        AND ic.column_id = fkc.parent_column_id
        AND ic.key_ordinal = 1);
```

### 5.2 Đối soát số dư với sổ cái (kỳ vọng 0 dòng)

```sql
SELECT u.user_id, u.email, u.xu_balance, l.balance_after
FROM users u
OUTER APPLY (
    SELECT TOP 1 balance_after
    FROM xu_transactions t
    WHERE t.user_id = u.user_id
    ORDER BY t.created_at DESC, t.txn_id DESC
) l
WHERE (l.balance_after IS NULL AND u.xu_balance <> 0)
   OR l.balance_after <> u.xu_balance;
```

### 5.3 Đối soát ngân sách đã dùng với lượt xem hoàn tất (kỳ vọng 0 dòng)

```sql
SELECT a.ad_id, a.title, a.spent_xu,
       ISNULL(SUM(CASE WHEN v.view_status = 'COMPLETED' THEN v.reward_xu END), 0) AS tong_tu_ad_views
FROM ads a
LEFT JOIN ad_views v ON v.ad_id = a.ad_id
GROUP BY a.ad_id, a.title, a.spent_xu
HAVING a.spent_xu <> ISNULL(SUM(CASE WHEN v.view_status = 'COMPLETED' THEN v.reward_xu END), 0);
```

### 5.4 Top 20 bảng xếp hạng trong 7 ngày (đổi khoảng thời gian cho tháng hoặc toàn thời gian)

```sql
SELECT TOP 20 u.user_id, u.full_name, SUM(t.amount) AS xu_kiem_duoc
FROM xu_transactions t
JOIN users u ON u.user_id = t.user_id
WHERE t.txn_type IN ('EARN', 'BONUS')
  AND u.account_status = 'ACTIVE'
  AND u.system_role = 'VIEWER'
  AND t.created_at >= DATEADD(DAY, -7, SYSDATETIME())
GROUP BY u.user_id, u.full_name
ORDER BY xu_kiem_duoc DESC, u.user_id;
```

Sổ cái không có cờ "đã hủy". Việc thu hồi xu được ghi bằng dòng `ADJUST` âm, và query trên không trừ phần này (chỉ loại tài khoản bị khóa). Cả nhóm cần chốt định nghĩa "xu kiếm được" rồi ghi vào tài liệu.

## 6. Việc cần làm tiếp

1. Chạy 5.1, 5.2, 5.3 trên database của bạn và ghi kết quả vào cột "Trạng thái" ở mục 3.
2. Đối chiếu mục 2 với migration Sprint 5 của bạn (bảng, ràng buộc UNIQUE chống nhận thưởng hai lần, index).
3. Xác nhận lỗi QUOTED_IDENTIFIER (mục 3, dòng 5) bằng cách chạy đúng lệnh README trên máy sạch.
4. Đo trước/sau mỗi index bằng `SET STATISTICS IO, TIME ON` và ghi vào báo cáo kiểm thử.
